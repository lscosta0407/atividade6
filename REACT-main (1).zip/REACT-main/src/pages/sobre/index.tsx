import {Link} from 'react-router-dom'
export default function Sobre() {
    return (
        <>
            <h1>Quem desenvolveu o projeto</h1>
            <hr/>
            <div>Lorem ipsum dolor sit amet consectetur adipisicing elit, Gabrela Natsumi Kawaguchi. 
            Perspiciatis, laborum est corrupti mollitia delectus inventore aut. 
            Ab omnis veritatis quaerat a unde cum numquam, iure animi quasi voluptas delectus aperiam.
            Fugiat, harum cum, eum quo excepturi ipsum illum voluptates debitis perspiciatis illo corporis soluta alias, sed cumque odit ad voluptatem delectus ex.</div>
            <hr/>
            <Link to="/">Página Inicial</Link>        
        </>
    )
}